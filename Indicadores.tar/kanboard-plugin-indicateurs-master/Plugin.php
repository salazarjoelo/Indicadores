<?php

namespace Kanboard\Plugin\Indicadores;

use Kanboard\Core\Plugin\Base;
use Kanboard\Core\Security\Role;

class Plugin extends Base
{
    public function initialize()
    {
        $this->applicationAccessMap->add('IndicadoresController', '*', Role::APP_USER);

        $this->template->hook->attach('template:project-list:menu:after', 'Indicadores:menu');
        $this->template->hook->attach('template:dashboard:page-header:menu', 'Indicadores:menu');

        $this->route->enable();
        $this->route->addRoute('/Indicadores', 'IndicadoresController', 'index', 'Indicadores');

        $this->setContentSecurityPolicy(array('script-src' => "'self' 'unsafe-inline' 'unsafe-eval'"));
    }

    public function getClasses()
    {
        return array();
    }

    public function getPluginName()
    {
        return 'Indicadores';
    }

    public function getPluginDescription()
    {
        return t("Indicadores : état d'avancement des projets, nombre de projets par service, vue synthétique des projets");
    }

    public function getPluginAuthor()
    {
        return 'Jade Tavernier, Pascal Rigaux';
    }

    public function getPluginVersion()
    {
        return '1.0';
    }

    public function getPluginHomepage()
    {
        return 'https://github.com/UnivParis1/kanboard-plugin-Indicadores';
    }
}
