<li>
  <?= $this->url->icon('line-chart', t('Indicadores'), 'IndicadoresController', 'index', [ 'plugin' => 'Indicadores' ]) ?>
</li>