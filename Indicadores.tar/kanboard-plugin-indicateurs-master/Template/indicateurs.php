<?= $this->asset->css('plugins/Indicadores/css/Indicadores.css') ?>

<?php
include "main.html";
?>  

<script>
var params = <?= json_encode($params, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) ?>;
</script>

<?= $this->asset->js('plugins/Indicadores/js/highcharts.js') ?>
<?= $this->asset->js('plugins/Indicadores/js/vue.js') ?>
<?= $this->asset->js('plugins/Indicadores/js/Indicadores.js') ?>
